# app/utils/__init__.py
# Torna 'utils' um pacote Python.
