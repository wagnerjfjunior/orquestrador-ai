# ==============================
# app/gemini_client.py
# ==============================
from __future__ import annotations

import os
import time
import asyncio
from typing import Dict, Any

import google.generativeai as genai

# ---------------------------
# Configuração
# ---------------------------
_GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
_DEFAULT_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
_TIMEOUT = float(os.getenv("GEMINI_TIMEOUT", "25"))
_FORCE_JSON = True

_genai_inited = False


def _init():
    """Inicializa SDK Gemini uma única vez."""
    global _genai_inited
    if _genai_inited:
        return
    if not _GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY ausente do ambiente")
    genai.configure(api_key=_GEMINI_API_KEY)
    _genai_inited = True


# ---------------------------
# Pergunta “normal” (não obriga JSON)
# ---------------------------
async def ask(
    prompt: str,
    *,
    system: str | None = None,
    model: str = _DEFAULT_MODEL,
    temperature: float = 0.2,
    timeout: float = _TIMEOUT,
) -> Dict[str, Any]:
    """
    Envia pergunta ao Gemini (não obriga JSON).
    Retorna: { model, answer, latency_ms }.
    """
    _init()
    t0 = time.perf_counter()

    def _call():
        m = genai.GenerativeModel(model_name=model, system_instruction=system or None)
        return m.generate_content(prompt, generation_config={"temperature": temperature})

    try:
        resp = await asyncio.to_thread(_call)
        text = getattr(resp, "text", None) or str(resp)
        return {
            "model": model,
            "answer": text,
            "latency_ms": int((time.perf_counter() - t0) * 1000),
        }
    except Exception as e:
        raise RuntimeError(f"Gemini error: {str(e)}") from e


# ---------------------------
# Julgamento (força JSON)
# ---------------------------
async def judge(
    system: str,
    user: str,
    *,
    model: str = _DEFAULT_MODEL,
    force_json: bool = True,
    temperature: float = 0.0,
    timeout: float = _TIMEOUT,
) -> str:
    """
    Prompta o Gemini para atuar como juiz.
    Retorna TEXTO cru (esperado ser JSON).
    """
    _init()

    sysmsg = system
    if force_json or _FORCE_JSON:
        sysmsg = (
            system
            + "\n\nIMPORTANTE: Responda ESTRITAMENTE com UM ÚNICO objeto JSON válido, sem markdown."
        )

    def _call():
        m = genai.GenerativeModel(
            model_name=model,
            system_instruction=sysmsg,
            generation_config={
                "temperature": temperature,
                "response_mime_type": "application/json"
                if (force_json or _FORCE_JSON)
                else "text/plain",
            },
        )
        return m.generate_content(user)

    try:
        resp = await asyncio.to_thread(_call)
        return getattr(resp, "text", None) or str(resp)
    except Exception as e:
        raise RuntimeError(f"Gemini judge error: {str(e)}") from e


# ---------------------------
# Compatibilidade com imports antigos
# ---------------------------
def is_configured() -> bool:
    """Retorna True se a API key do Gemini estiver configurada."""
    return bool(_GEMINI_API_KEY)


# Backward-compat: nomes esperados no main.py
ask_gemini = ask  # alias async
