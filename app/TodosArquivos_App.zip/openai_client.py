# ==============================
# app/openai_client.py
# ==============================
from __future__ import annotations

import os
import time
import asyncio
from dataclasses import dataclass
from typing import Dict, Any, Optional

from openai import OpenAI

# ---------------------------------------------------------
# Settings (mantém compatibilidade com testes via monkeypatch)
# ---------------------------------------------------------
@dataclass
class _Settings:
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    OPENAI_TIMEOUT: float = float(os.getenv("OPENAI_TIMEOUT", "25"))
    OPENAI_FORCE_JSON: bool = os.getenv("OPENAI_FORCE_JSON", "false").lower() == "true"

settings = _Settings()

_client: Optional[OpenAI] = None


def _init_client() -> OpenAI:
    """Inicializa o cliente OpenAI uma única vez."""
    global _client
    if _client is not None:
        return _client
    if not settings.OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY ausente do ambiente")
    _client = OpenAI(api_key=settings.OPENAI_API_KEY)
    return _client


def is_configured() -> bool:
    """True se a API key do OpenAI estiver configurada."""
    return bool(settings.OPENAI_API_KEY)


# ---------------------------------------------------------
# Pergunta “normal” (não obriga JSON)
# ---------------------------------------------------------
async def ask(
    prompt: str,
    *,
    system: str | None = None,
    model: str = None,
    temperature: float = 0.2,
    timeout: float = None,
) -> Dict[str, Any]:
    """
    Envia pergunta ao OpenAI (não obriga JSON).
    Retorna: { model, answer, latency_ms }.
    """
    client = _init_client()
    model = model or settings.OPENAI_MODEL
    timeout = timeout if timeout is not None else settings.OPENAI_TIMEOUT

    t0 = time.perf_counter()

    def _call():
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        # Nota: usamos /chat.completions por compatibilidade ampla.
        resp = client.chat.completions.create(
            model=model,
            messages=msgs,
            temperature=temperature,
            timeout=timeout,
        )
        return resp

    try:
        resp = await asyncio.to_thread(_call)
        choice = resp.choices[0].message
        text = (choice.content or "").strip()
        return {
            "model": model,
            "answer": text,
            "latency_ms": int((time.perf_counter() - t0) * 1000),
        }
    except Exception as e:
        raise RuntimeError(f"OpenAI error: {str(e)}") from e


# ---------------------------------------------------------
# Julgamento (pode forçar JSON)
# ---------------------------------------------------------
async def judge(
    system: str,
    user: str,
    *,
    model: str = None,
    force_json: bool = True,
    temperature: float = 0.0,
    timeout: float = None,
) -> str:
    """
    Prompta o OpenAI para atuar como juiz.
    Retorna TEXTO cru (esperado ser JSON quando force_json=True).
    """
    client = _init_client()
    model = model or settings.OPENAI_MODEL
    timeout = timeout if timeout is not None else settings.OPENAI_TIMEOUT

    sysmsg = system
    response_format = None
    if force_json or settings.OPENAI_FORCE_JSON:
        # Usa o response_format oficial para JSON válido.
        response_format = {"type": "json_object"}

    def _call():
        msgs = [{"role": "system", "content": sysmsg}, {"role": "user", "content": user}]
        resp = client.chat.completions.create(
            model=model,
            messages=msgs,
            temperature=temperature,
            response_format=response_format,
            timeout=timeout,
        )
        return resp

    try:
        resp = await asyncio.to_thread(_call)
        choice = resp.choices[0].message
        text = (choice.content or "").strip()
        return text
    except Exception as e:
        raise RuntimeError(f"OpenAI judge error: {str(e)}") from e


# ---------------------------------------------------------
# Aliases esperados pelo main.py (retrocompat)
# ---------------------------------------------------------
ask_openai = ask  # alias async
